package com.jw.sc.config;

import org.springframework.context.annotation.Configuration;

@Configuration

public class MybatisConfig {
}
