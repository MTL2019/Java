package com.jw.sc.service;

public interface IMessageProvider {
    public String send();

//    public void sendsms();
}
