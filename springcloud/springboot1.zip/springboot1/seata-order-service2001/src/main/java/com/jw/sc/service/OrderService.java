package com.jw.sc.service;

import com.jw.sc.domain.Order;

public interface OrderService {

    void create(Order order);

}
